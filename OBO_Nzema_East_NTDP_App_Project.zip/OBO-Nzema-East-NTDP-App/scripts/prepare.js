// Copies Chart.js, SheetJS and the Poppins font into www/vendor so the app works fully offline.
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..'), out = path.join(root, 'www', 'vendor');
fs.mkdirSync(path.join(out, 'fonts'), { recursive: true });
const cp = (from, to) => fs.copyFileSync(path.join(root, 'node_modules', from), path.join(out, to));
cp('chart.js/dist/chart.umd.js', 'chart.umd.js');
cp('xlsx/dist/xlsx.full.min.js', 'xlsx.full.min.js');
[300, 400, 500].forEach(w => cp(`@fontsource/poppins/files/poppins-latin-${w}-normal.woff2`, `fonts/poppins-${w}.woff2`));
console.log('Offline assets ready in www/vendor');
