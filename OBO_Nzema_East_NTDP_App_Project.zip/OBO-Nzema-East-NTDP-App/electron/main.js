const { app, BrowserWindow, Menu } = require('electron');
const path = require('path');
function createWindow() {
  const w = new BrowserWindow({
    width: 1280, height: 850, minWidth: 380, backgroundColor: '#eef2f6',
    title: 'OBO Nzema East NTDP',
    icon: path.join(__dirname, '..', 'build', 'icon.png'),
    webPreferences: { contextIsolation: true, sandbox: true }
  });
  Menu.setApplicationMenu(null);
  w.loadFile(path.join(__dirname, '..', 'www', 'index.html'));
  w.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
}
app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());
